# Contributing to dalek-rangeproofs

If you have questions, feature requests, or comments, please feel free to join
our #python-gnupg IRC channel on [Freenode](https://freenode.net/).

Patches are welcomed as pull requests on
[our Github](https://github.com/isislovecruft/python-gnupg), as well as by
email to isis@patternsinthevoid.net or to any of the contributors with
commit access.

Some issues are easier than others. The `easy` label can be used to find the
easy issues. If you want to work on an issue, please leave a comment so that we
can assign it to you!

# Code of Conduct

Please see our
[Code of Conduct](https://github.com/isislovecruft/python-gnupg/blob/develop/CODE_OF_CONDUCT.md).
